import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import App from './App';
import './App.css';
import Edit from './components/Edit';
import Create from './components/Create';
import Show from './components/Show';

import EditDrive from './components/drives/Edit';
import CreateDrive from './components/drives/Create';
import ShowDrive from './components/drives/Show';
import ListDrive from './components/drives/List';

import EditCandidates from './components/candidates/Edit';
import CreateCandidates from './components/candidates/Create';
import ShowCandidates from './components/candidates/Show';
import ListCandidates from './components/candidates/List';

import EditFacilitators from './components/facilitators/Edit';
import CreateFacilitators from './components/facilitators/Create';
import ShowFacilitators from './components/facilitators/Show';
import ListFacilitators from './components/facilitators/List';

ReactDOM.render(
  <Router>
      <div>
        <Route exact path='/companies' component={App} />
        <Route path='/companies/edit/:id' component={Edit} />
        <Route path='/companies/create' component={Create} />
        <Route path='/companies/show/:id' component={Show} />

        <Route exact path='/companies/show/:id/drives' component={ListDrive} />
        <Route path='/companies/show/:id/drives/edit/:id' component={EditDrive} />
        <Route path='/companies/show/:id/drives/create' component={CreateDrive} />
        <Route path='/companies/show/:id/drives/show/:id' component={ShowDrive} />

        <Route exact path='/candidates' component={ListCandidates} />
        <Route path='/candidates/edit/:id' component={EditCandidates} />
        <Route path='/candidates/create' component={CreateCandidates} />
        <Route path='/candidates/show/:id' component={ShowCandidates} />

        <Route exact path='/facilitators' component={ListFacilitators} />
        <Route path='/facilitators/edit/:id' component={EditFacilitators} />
        <Route path='/facilitators/create' component={CreateFacilitators} />
        <Route path='/facilitators/show/:id' component={ShowFacilitators} />
      </div>
  </Router>,
  document.getElementById('root')
);